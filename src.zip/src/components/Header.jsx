
import './Header.css'
function Header() {
return(
    <>
<header>
        <nav class="nav">
            <h1>Blog</h1>
            <ul>
                <li><a href="index.html">Home <i class="fas fa-home"></i></a></li>
                <li><a href="#">About <i class="fas fa-info-circle"></i></a></li>
                <li><a href="#">Service <i class="fas fa-briefcase"></i></a></li>
                <li><a href="#">Contact <i class="fas fa-envelope"></i></a></li>
            </ul>
        </nav>
    </header>
    </>
  )
}

export default Header
