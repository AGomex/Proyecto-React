
import './Logo.css'
import agregar from '../assets/agregar.svg'
function Logo() {
return(
    <>
 <div class="hero">
            <h1>Your Journey Your Story</h1>
            <h2>Choose Your Favorite Destination.</h2>
            <a href="create_blog.html">
                <img src={agregar} alt="Menu" class="svg-fixed-bottom-right"/>
            </a>
        </div>
    </>
  )
}

export default Logo