import React, { useEffect } from 'react';
import './Main.css'
const Blog = () => {
  useEffect(() => {
    const mainSection = document.getElementById('main');
    const blogManager = new BlogManager(mainSection);

    blogManager.loadBlogEntries();
  }, []);

  return (
    <div>
      <header>
        <nav className="nav">
          <h1>Blog</h1>
          <ul>
            <li><a href="#">Home <i className="fas fa-home"></i></a></li>
            <li><a href="#">About <i className="fas fa-info-circle"></i></a></li>
            <li><a href="#">Service <i className="fas fa-briefcase"></i></a></li>
            <li><a href="#">Contact <i className="fas fa-envelope"></i></a></li>
          </ul>
        </nav>
        <div className="hero">
          <h1>Your Journey Your Story</h1>
          <h2>Choose Your Favorite Destination.</h2>
          <a href="create_blog.html">
            <img src="agregar.svg" alt="Menu" className="svg-fixed-bottom-right" />
          </a>
        </div>
      </header>
      <main className="main" id="main">
        <section>
          {/* Las cards serán generadas dinámicamente */}
        </section>
      </main>
    </div>
  );
};

class BlogManager {
  constructor(mainSection) {
    this.mainSection = mainSection;
  }

  loadBlogEntries() {
    let exampleCardExists = false;

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key.includes('blogEntry_')) {
        const entry = JSON.parse(localStorage.getItem(key));
        const blogCard = new BlogCard(entry);
        this.mainSection.appendChild(blogCard.createCard());

        exampleCardExists = true;
      }
    }

    if (!exampleCardExists) {
      const exampleCard = new ExampleCard();
      this.mainSection.appendChild(exampleCard.createCard());
    }
  }
}

class BlogCard {
  constructor(entry) {
    this.entry = entry;
  }

  createCard() {
    const card = document.createElement('div');
    card.className = 'card';

    const cardContent = document.createElement('div');
    cardContent.className = 'card-content';
    cardContent.innerHTML = `
      <h2 class="title">${this.entry.title}</h2>
      <div class="info">
        <span>Author: ${this.entry.author}</span>
        <span>Category: ${this.entry.category}</span>
      </div>
      <p class="text">${this.entry.content.substring(0, 150)}...</p>
      <a href="blog.html" class="read-more">Read more →</a>
      <button class="comment-btn" onclick="toggleCommentForm(this)">Comments</button>
      <form class="comment-form" style="display: none;" onsubmit="submitComment(event)">
        <textarea placeholder="Enter your comment"></textarea>
        <button type="submit">Submit</button>
      </form>`;

    const imageDiv = document.createElement('div');
    imageDiv.className = 'image';

    const img = document.createElement('img');
    img.src = this.entry.image;
    img.alt = 'Blog Image';

    imageDiv.appendChild(img);
    card.appendChild(cardContent);
    card.appendChild(imageDiv);

    return card;
  }
}

class ExampleCard {
  createCard() {
    const card = document.createElement('div');
    card.className = 'card';

    const cardContent = document.createElement('div');
    cardContent.className = 'card-content';
    cardContent.innerHTML = `
      <h2 class="title">Card Principal</h2>
      <div class="info">
        <span>Author: John Doe</span>
        <span>Category: Travel</span>
      </div>
      <p class="text">Ever tried driving without GPS? Boom! That's why websites need headers for direction.</p>
      <a href="blog.html" class="read-more">Read more →</a>
      <button class="comment-btn" onclick="toggleCommentForm(this)">Comments</button>
      <form class="comment-form" style="display: none;" onsubmit="submitComment(event)">
        <textarea placeholder="Enter your comment"></textarea>
        <button type="submit">Submit</button>
      </form>`;

    const imageDiv = document.createElement('div');
    imageDiv.className = 'image';

    const img = document.createElement('img');
    img.src = 'pikachu.jpg'; // Ruta a la imagen de ejemplo
    img.alt = 'Pikachu';

    imageDiv.appendChild(img);
    card.appendChild(cardContent);
    card.appendChild(imageDiv);

    return card;
  }
}

function toggleCommentForm(button) {
  const cardContent = button.parentElement;
  const commentForm = cardContent.querySelector('.comment-form');
  commentForm.style.display = commentForm.style.display === 'none' || commentForm.style.display === '' ? 'block' : 'none';
}

function submitComment(event) {
  event.preventDefault();

  const commentForm = event.target;
  const textarea = commentForm.querySelector('textarea');
  const commentText = textarea.value;

  console.log('Comentario enviado:', commentText);

  commentForm.style.display = 'none';
}

export default Blog;
